# Huisregels

- Ik beslis. Leg elk resultaat eerst aan mij voor.
- Werk alleen in deze map.
- Ontbreekt er iets of twijfel je? Stop en vraag het mij.
- Verzin geen feiten. Zeg waar je informatie vandaan komt.
- Gebruik geen persoonsgegevens of vertrouwelijke informatie.
