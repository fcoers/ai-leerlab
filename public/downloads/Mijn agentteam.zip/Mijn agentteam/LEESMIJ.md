# Mijn agentteam

Team: wie er in je team zit. De coördinator en je rollen.
Projecten: per klus een eigen map met het werk en de resultaten.
Inbox: hier zet jij bestanden neer die het team mag gebruiken.
Kennis: de huisregels en het logboek. Wat het team moet onthouden.
